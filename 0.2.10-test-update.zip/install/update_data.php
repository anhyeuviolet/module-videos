<?php

/**
 * @Project VIDEO CLIPS AJAX 4.x
 * @Author KENNY NGUYEN (nguyentiendat713@gmail.com)
 * @Copyright (C) 2014 KENNY NGUYEN. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Dec 01, 2014, 04:33:14 AM
 */

if (!defined('NV_IS_UPDATE'))
    die('Stop!!!');

$nv_update_config = array();

// Kieu nang cap 1: Update; 2: Upgrade
$nv_update_config['type'] = 1;

// ID goi cap nhat
$nv_update_config['packageID'] = 'NVUDVIDEOS0201';

// Cap nhat cho module nao, de trong neu la cap nhat NukeViet, ten thu muc module neu la cap nhat module
$nv_update_config['formodule'] = 'videos';

// Thong tin phien ban, tac gia, ho tro
$nv_update_config['release_date'] = 1463702400;
$nv_update_config['author'] = 'KENNY NGUYEN (nguyentiendat713@gmail.com)';
$nv_update_config['support_website'] = 'https://github.com/anhyeuviolet/module-videos/issues';
$nv_update_config['to_version'] = '0.2.01';
$nv_update_config['allow_old_version'] = array(
    '0.1.08',
    '0.1.09',
    '0.1.10'
);

// 0:Nang cap bang tay, 1:Nang cap tu dong, 2:Nang cap nua tu dong
$nv_update_config['update_auto_type'] = 1;

$nv_update_config['lang'] = array();
$nv_update_config['lang']['vi'] = array();

// Tiếng Việt
$nv_update_config['lang']['vi']['nv_up_p1'] = 'Thay đổi cấu trúc bảng dữ liệu';
$nv_update_config['lang']['vi']['nv_up_p2'] = 'Cập nhật bảng thông tin Uploader';
$nv_update_config['lang']['vi']['nv_up_body_html'] = 'Thay đổi cấu trúc bảng body_html';
$nv_update_config['lang']['vi']['nv_up_delunuse_files'] = 'Xoá bỏ các file cũ';
$nv_update_config['lang']['vi']['nv_up_finish'] = 'Đánh dấu phiên bản mới';

$nv_update_config['tasklist'] = array();
$nv_update_config['tasklist'][] = array(
    'r' => '0.2.01',
    'rq' => 1,
    'l' => 'nv_up_p1',
    'f' => 'nv_up_p1'
);

$nv_update_config['tasklist'][] = array(
    'r' => '0.2.01',
    'rq' => 1,
    'l' => 'nv_up_p2',
    'f' => 'nv_up_p2'
);

$nv_update_config['tasklist'][] = array(
    'r' => '0.2.01',
    'rq' => 1,
    'l' => 'nv_up_body_html',
    'f' => 'nv_up_body_html'
);

$nv_update_config['tasklist'][] = array(
    'r' => '0.2.01',
    'rq' => 1,
    'l' => 'nv_up_delunuse_files',
    'f' => 'nv_up_delunuse_files'
);

$nv_update_config['tasklist'][] = array(
    'r' => '0.2.01',
    'rq' => 1,
    'l' => 'nv_up_finish',
    'f' => 'nv_up_finish'
);

// Danh sach cac function
/*
Chuan hoa tra ve:
array(
'status' =>
'complete' => 
'next' =>
'link' =>
'lang' =>
'message' =>
);
status: Trang thai tien trinh dang chay
- 0: That bai
- 1: Thanh cong
complete: Trang thai hoan thanh tat ca tien trinh
- 0: Chua hoan thanh tien trinh nay
- 1: Da hoan thanh tien trinh nay
next:
- 0: Tiep tuc ham nay voi "link"
- 1: Chuyen sang ham tiep theo
link:
- NO
- Url to next loading
lang:
- ALL: Tat ca ngon ngu
- NO: Khong co ngon ngu loi
- LangKey: Ngon ngu bi loi vi,en,fr ...
message:
- Any message
Duoc ho tro boi bien $nv_update_baseurl de load lai nhieu lan mot function
Kieu cap nhat module duoc ho tro boi bien $old_module_version
*/

$array_modlang_update = array();

// Lay danh sach ngon ngu
$result = $db->query("SELECT lang FROM " . $db_config['prefix'] . "_setup_language WHERE setup=1");
while (list($_tmp) = $result->fetch(PDO::FETCH_NUM)) {
    $array_modlang_update[$_tmp] = array("lang" => $_tmp, "mod" => array());

    // Get all module
    $result1 = $db->query("SELECT title, module_data FROM " . $db_config['prefix'] . "_" . $_tmp . "_modules WHERE module_file=" . $db->quote($nv_update_config['formodule']));
    while (list($_modt, $_modd) = $result1->fetch(PDO::FETCH_NUM)) {
        $array_modlang_update[$_tmp]['mod'][] = array("module_title" => $_modt, "module_data" => $_modd);
    }
}

/**
 * nv_up_p1()
 *
 * @return
 *
 */
function nv_up_p1()
{
    global $nv_update_baseurl, $db, $db_config, $nv_Cache, $array_modlang_update;

    $return = array(
        'status' => 1,
        'complete' => 1,
        'next' => 1,
        'link' => 'NO',
        'lang' => 'NO',
        'message' => ''
    );

    foreach ($array_modlang_update as $lang => $array_mod) {
        foreach ($array_mod['mod'] as $module_info) {
            $table_prefix = $db_config['prefix'] . "_" . $lang . "_" . $module_info['module_data'];
			
			$nquery = $db->query("SELECT catid FROM " . $table_prefix . "_cat");
				while (list ($catid) = $nquery->fetch(3)) {
					try {
						$db->query("ALTER TABLE " . $table_prefix . "_" . $catid . " ADD `vid_duration` varchar(250) default '' AFTER `vid_type`");
					} catch (PDOException $e) {
					//
				}
			}
            
            // Cap nhat function moi - v_funcs
			try {
				$db->query("UPDATE " . $db_config['prefix'] . $lang . "_modfuncs SET func_name='v_funcs', alias='v_funcs', func_custom_name='V_funcs' WHERE func_name='list_playlist' AND in_module='" . $module_info['module_name'] . "'");
				} catch (PDOException $e) {
                trigger_error($e->getMessage());
			}
			
            // Cap nhat cac cot moi
			try {
					$db->query("ALTER TABLE " . $table_prefix . "_rows ADD `vid_duration` varchar(250) default '' AFTER `vid_type`");
				} catch (PDOException $e) {
                trigger_error($e->getMessage());
			}
			// Cap nhat gia tri moi trong cau hinh module
			try 
			{
				$db->query("INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_info['module_name'] . "', 'youtube_api', '')");
				$db->query("INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_info['module_name'] . "', 'jwplayer_logo_pos', '')");
			} 
			catch (PDOException $e) 
			{
                trigger_error($e->getMessage());
			}
			
			try 
			{
				$db->query("INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_info['module_name'] . "', 'jwplayer_logo_pos', '')");
			} 
			catch (PDOException $e) 
			{
                trigger_error($e->getMessage());
			}
            // Bo sung cac bang moi
			$db->query("CREATE TABLE IF NOT EXISTS " . $table_prefix . "_uploaders (
				userid mediumint(8) NOT NULL,
				group_id smallint(5) unsigned NOT NULL DEFAULT '0',
				status mediumint(8) NOT NULL DEFAULT '1',
				username varchar(100) NOT NULL DEFAULT '',
				md5username char(32) NOT NULL DEFAULT '',
				email varchar(250) NOT NULL DEFAULT '',
				first_name varchar(100) NOT NULL DEFAULT '',
				last_name varchar(100) NOT NULL DEFAULT '',
				description text,
				view_mail tinyint(1) unsigned NOT NULL DEFAULT '0',
				PRIMARY KEY (userid)
			) ENGINE=MyISAM");
			
			$db->query("CREATE TABLE IF NOT EXISTS " . $table_prefix . "_rows_favourite (
				 fid smallint(5) unsigned NOT NULL,
				 id int(11) unsigned NOT NULL,
				 UNIQUE KEY fid (fid,id)
				) ENGINE=MyISAM");
			
			$db->query("CREATE TABLE IF NOT EXISTS " . $table_prefix . "_rows_report (
				 rid smallint(5) unsigned NOT NULL,
				 id int(11) unsigned NOT NULL,
				 UNIQUE KEY rid (rid,id)
				) ENGINE=MyISAM");
        }
    }

    return $return;
}

function nv_videos_check_uploader( $user_id, $table_name ){
	global $db, $global_config, $module_data, $module_name;
	$db->sqlreset()
	->select( 'userid' )
	->from(  $table_name . '_uploaders'  )
	->where( 'userid=' . $user_id );
	$query = $db->query( $db->sql() );
	$result = $query->fetch();
	if( $result > 0){
		return false;
	}else{
		return true;
	}
}

function nv_videos_getuser_info( $user_id, $table_name ){
	global $db, $nv_Cache, $global_config, $module_data, $module_name;
	$db->sqlreset()
	->select( 'userid, group_id, username, md5username, email, first_name, last_name' )
	->from( NV_USERS_GLOBALTABLE  )
	->where( 'userid=' . $user_id );
	$result = $db->query( $db->sql() );
	while( $uploader_info = $result->fetch() )
	{
		$stmt = $db->prepare('INSERT INTO ' . $table_name . '_uploaders VALUES(
		' . intval( $uploader_info['userid'] ) . ',
		' . intval( $uploader_info['group_id'] ) . ',
		1,
		:username,
		:md5username,
		:email,
		:first_name,
		:last_name,
		:description,
		0)'
		);
		
		$_des = $lang_module['about_uploader'] . $uploader_info['username'];
		$stmt->bindParam(':username', $uploader_info['username'], PDO::PARAM_STR);
		$stmt->bindParam(':md5username', $uploader_info['md5username'], PDO::PARAM_STR);
		$stmt->bindParam(':email', $uploader_info['email'], PDO::PARAM_STR);
		$stmt->bindParam(':first_name', $uploader_info['first_name'] , PDO::PARAM_STR);
		$stmt->bindParam(':last_name', $uploader_info['last_name'], PDO::PARAM_STR);
		$stmt->bindParam(':description', $_des, PDO::PARAM_STR);
		$stmt->execute();
	}
	$nv_Cache->delMod( $module_name );
}


/**
 * nv_up_p2()
 *
 * @return
 *
 */
function nv_up_p2()
{
    global $nv_update_baseurl, $db, $db_config, $nv_Cache, $array_modlang_update;

    $return = array(
        'status' => 1,
        'complete' => 1,
        'next' => 1,
        'link' => 'NO',
        'lang' => 'NO',
        'message' => ''
    );

    foreach ($array_modlang_update as $lang => $array_mod) {
        foreach ($array_mod['mod'] as $module_info) {
            $table_prefix = $db_config['prefix'] . "_" . $lang . "_" . $module_info['module_data'];

			$db->sqlreset()
			->select( 'admin_id' )
			->from( $table_prefix . '_rows'  )
			->group('admin_id');
			
			$result = $db->query( $db->sql() );
			while( $admin_id = $result->fetch() )
			{
				foreach ( $admin_id as $admin_id_i){
					$_ck = nv_videos_check_uploader( $admin_id_i, $table_prefix );
					if( $_ck ){
						nv_videos_getuser_info( $admin_id_i, $table_prefix );
					}
				}
				
			}
            
        }
    }

    return $return;
}

/**
 * nv_up_body_html()
 *
 * @return
 *
 */
function nv_up_body_html()
{
    global $nv_update_baseurl, $db, $db_config, $nv_Request;

    $return = array(
        'status' => 1, // Trạng thái hoàn thành 1 lần chạy
        'complete' => 1, // Trạng thái hoàn thành cả công việc
        'next' => 1, // Qua bước tiếp theo hay tiếp tục bước này
        'link' => 'NO', // Link tiếp tục nếu có
        'lang' => 'NO', // Ngôn ngữ có vấn đề
        'message' => ''
    ); // Vấn đề cụ thể


    // Tất cả các bảng cần update
    $array_tbprefix_update = array();

    $language_query = $db->query('SELECT lang FROM ' . $db_config['prefix'] . '_setup_language WHERE setup = 1');
    while (list ($lang) = $language_query->fetch(3)) {
        // Lấy tất cả các module và module ảo của videos
        $mquery = $db->query("SELECT title, module_data FROM " . $db_config['prefix'] . "_" . $lang . "_modules WHERE module_file = 'videos'");
        while (list ($mod, $mod_data) = $mquery->fetch(3)) {
            $array_tbprefix_update[] = $db_config['prefix'] . "_" . $lang . "_" . $mod_data;
        }
    }

    // Kết thúc nếu không có module videos
    if (empty($array_tbprefix_update)) {
        return $return;
    }

    $request = array();
    $request['umodkey'] = $nv_Request->get_int('umodkey', 'get,post', 0); // Cập nhật cho module nào
    $request['ustep'] = $nv_Request->get_int('ustep', 'get,post', 0); // Bước 0: RENAME, 1: COPY AND DELETE TABLE, 2: DELETE bodytext


    // Kết thúc quá trình nếu hết bảng update
    if (!isset($array_tbprefix_update[$request['umodkey']])) {
        return $return;
    }

    $return['complete'] = 0;
    $return['next'] = 0;

    // Rename bảng bodyhtml_1
    if ($request['ustep'] == 0) {
        try {
            $db->query("RENAME TABLE " . $array_tbprefix_update[$request['umodkey']] . "_bodyhtml_1 TO " . $array_tbprefix_update[$request['umodkey']] . "_detail");
        } catch (PDOException $e) {
            // Xem như bảng detail đã tồn tại
        }

        // Chuyển sang bước 2
        $request['ustep']++;
        $return['link'] = $nv_update_baseurl . '&umodkey=' . $request['umodkey'] . '&ustep=' . $request['ustep'];
    } elseif ($request['ustep'] == 1) {
        $result = $db->query('SHOW TABLE STATUS LIKE ' . $db->quote($array_tbprefix_update[$request['umodkey']] . '_bodyhtml_%'));
        $html_table = "";
        while ($item = $result->fetch()) {
            if (preg_match("/^" . preg_quote($array_tbprefix_update[$request['umodkey']]) . "\_bodyhtml\_([0-9]+)$/", $item['name']) and $item['name'] != ($array_tbprefix_update[$request['umodkey']] . '_bodyhtml_1')) {
                $html_table = $item['name'];
                break;
            }
        }

        // Hết bảng HTML thì chuyển bước tiếp
        if (empty($html_table)) {
            $request['ustep']++;
            $return['link'] = $nv_update_baseurl . '&umodkey=' . $request['umodkey'] . '&ustep=' . $request['ustep'];
            return $return;
        }

        // Copy dữ liệu
        try {
            $sql = "INSERT INTO " . $array_tbprefix_update[$request['umodkey']] . "_detail SELECT * FROM " . $html_table;
            $db->query($sql);
        } catch (PDOException $e) {
            $return['status'] = 0;
            $return['message'] = $e->getMessage();
            return $return;
        }

        // Xóa bảng
        try {
            $db->query("DROP TABLE " . $html_table);
        } catch (PDOException $e) {
            $return['status'] = 0;
            $return['message'] = $e->getMessage();
            return $return;
        }

        // Tiếp tục lặp lại bước này
        $return['link'] = $nv_update_baseurl . '&umodkey=' . $request['umodkey'] . '&ustep=' . $request['ustep'];
        return $return;
    } else {
        try {
            $db->query("DROP TABLE " . $array_tbprefix_update[$request['umodkey']] . "_bodytext");
        } catch (PDOException $e) {
            // Nothing
        }

        $request['umodkey']++;
        $request['ustep'] = 0;
        $return['link'] = $nv_update_baseurl . '&umodkey=' . $request['umodkey'] . '&ustep=' . $request['ustep'];
    }

    return $return;
}

/**
 * nv_up_delunuse_files()
 *
 * @return
 *
 */
function nv_up_delunuse_files()
{
    global $nv_update_baseurl, $db, $db_config;

    $return = array(
        'status' => 1,
        'complete' => 1,
        'next' => 1,
        'link' => 'NO',
        'lang' => 'NO',
        'message' => ''
    );

    nv_deletefile(NV_ROOTDIR . '/modules/videos/funcs/list_playlist.php', false);
    nv_deletefile(NV_ROOTDIR . '/themes/default/images/videos/loading.gif', false);
    nv_deletefile(NV_ROOTDIR . '/themes/default/images/videos/no_cover.jpg', false);
    nv_deletefile(NV_ROOTDIR . '/themes/default/images/videos/playbutton_180.png', false);
    nv_deletefile(NV_ROOTDIR . '/themes/default/images/videos/video_thumbnail.jpg', false);

    return $return;
}

/**
 * nv_up_finish()
 *
 * @return
 *
 */
function nv_up_finish()
{
    global $nv_update_baseurl, $db, $db_config, $nv_Cache, $nv_update_config;

    $return = array(
        'status' => 1,
        'complete' => 1,
        'next' => 1,
        'link' => 'NO',
        'lang' => 'NO',
        'message' => ''
    );

    try {
        $num = $db->query("SELECT COUNT(*) FROM " . $db_config['prefix'] . "_setup_extensions WHERE basename='" . $nv_update_config['formodule'] . "' AND type='module'")->fetchColumn();
        $version = "0.2.01 1463702400";
        
        if (!$num) {
            $db->query("INSERT INTO " . $db_config['prefix'] . "_setup_extensions (
                id, type, title, is_sys, is_virtual, basename, table_prefix, version, addtime, author, note
            ) VALUES (
                313, 'module', 'videos', 0, 1, 'videos', 'videos', '0.2.01 1463702400', " . NV_CURRENTTIME . ", 'KENNY NGUYEN (nguyentiendat713@gmail.com)', 
                'Module Videos based on NukeViet 4.x'
            )");
        } else {
            $db->query("UPDATE " . $db_config['prefix'] . "_setup_extensions SET 
                id=313, 
                version='" . $version . "', 
                author='KENNY NGUYEN (nguyentiendat713@gmail.com)' 
            WHERE basename='" . $nv_update_config['formodule'] . "' AND type='module'");
        }
    } catch (PDOException $e) {
        trigger_error($e->getMessage());
    }

    $nv_Cache->delAll();
    return $return;
}
